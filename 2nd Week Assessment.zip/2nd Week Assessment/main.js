const express = require('express');
const app = express();
const fs = require('fs');
const port = 3000;
read = fs.readFileSync('input.txt', 'utf-8');
app.get('/', (req, res) => {
    res.send(read);
});
app.post('/:id', (req, res) => {
    fs.writeFileSync('input.txt',req.params['id']);
});
app.put('/:id', (req, res) => {
    fs.appendFileSync('input.txt',req.params['id']);
});
app.listen(port, () => {
    console.log('Port Using',{port})
});