const fs = require('fs'); 
let first = fs.readFileSync('input.txt', 'utf-8');
let second = first.split('\n');
const express = require('express');
const app = express();
const port = 3000;
app.get('/', (req,res) => {
for (i=0; i<second.length; i++){
    txt = second[i].slice(second[i].indexOf(':')+1)+ '\n';
    res.send(txt);
    console.log(txt);
}
});
app.listen(port, function(){
    console.log('port using ',port)
})
