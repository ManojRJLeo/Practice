const fs = require('fs'); 
let first = fs.readFileSync('input.txt', 'utf-8');
let second = first.split('\n');
console.log(second);
for (i=0; i<second.length; i++){
    txt = second[i].slice(second[i].indexOf(':')+1);
    console.log(txt);
} 