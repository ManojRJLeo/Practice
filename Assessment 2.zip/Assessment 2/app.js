const express = require('express');
const app = express();
const { Sequelize, DataTypes } = require('sequelize');

app.use(express.json());

const model = new Sequelize({
    dialect: 'sqlite',
    storage: 'database.sqlite'
});