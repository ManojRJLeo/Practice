const express = require('express');
const app = express();
const fs = require('fs');
const port = 3000;
read = fs.readFileSync('input.txt', 'utf-8');
app.get('/', (req, res) => {
    res.send(read);
});
console.log(read);
app.listen(port, () => {
    console.log('Port Using',{port})
});