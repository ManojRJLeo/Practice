const express = require('express');
const app = express();
const fs = require('fs');
const port = 3001;
fs.writeFileSync('input.txt','Hi')
read = fs.readFileSync('input.txt', 'utf-8');
app.get('/', (req, res) => {
    res.send(read);
});
console.log(read);
app.listen(port, () => {
    console.log('Port Using',{port})
});