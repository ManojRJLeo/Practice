function c() {
    console.log('In function c');
}
module.exports = c;