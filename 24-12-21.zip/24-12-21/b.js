
function b() {
    console.log('In function b');
}
console.log(b());