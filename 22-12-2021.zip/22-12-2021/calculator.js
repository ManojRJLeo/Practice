// ***** calculator.js file *****
class Calculator {
      
    // Constructor to create object of the class
    Calculator() {
          
    }
  
    // Prefix increment operation
    preIncrement(a) {
        return ++a;
    }
  
    // Postfix increment operation
    postIncrement(a) {
        return a++;
    }
  
    // Prefix decrement operation
    preDecrement(a) {
        return --a;
    }
  
    // Postfix decrement operation
    postDecrement(a) {
        return a--;
    }
  
    // Addition of two numbers
    add(a, b) {
        return a + b;
    }
  
    // Subtraction of two numbers
    subtract(a, b) {
        return a - b;
    }
  
    // Division of two numbers
    divide(a, b) {
        return a / b;
    }
  
    // Multiplication of two numbers
    multiply(a, b){
        return a * b;
    }
}
  
// Exporting Calculator as attaching
// it to the module object
module.exports= Calculator;