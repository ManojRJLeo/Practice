// ***** app.js file  ******
// Importing Calculator class
const Calculator = require('./calculator.js');
  
// Creating object of calculator class
const calc = new Calculator();
  
/* Using all the member methods 
defined in Calculator */
  
console.log(calc.preIncrement(5))
  
console.log(calc.postIncrement(5))
  
console.log(calc.preDecrement(6))
  
console.log(calc.postDecrement(6))
  
console.log(calc.add(5, 6))
  
console.log(calc.subtract(5, 6))
  
console.log(calc.divide(5, 6))
  
console.log(calc.multiply(5, 6))