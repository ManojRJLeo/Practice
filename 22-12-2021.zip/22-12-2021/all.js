const express = require('express');
const app = express();
const bodyparser = require('body-parser');

app.use(bodyparser.urlencoded({extended:true}));

app.get('/',(req,res) => {
    res.sendFile(__dirname+'/index.html')
})

app.post('/:id',(req,res) => {
    const num1 = req.body.n1;
    const num2 = req.body.n2;
    if (req.params.id=="add"){
    const add = num1 + num2;
    res.send('the value is '+add);
    }
    else if (req.params.id=="sub"){
    const sub = num1 - num2;
    res.send('the value is '+sub);
    }
    else if (req.params.id=="mul"){
    const mul = num1 * num2;
    res.send('the value is '+mul);
    }
    else if (req.params.id=="div"){
    const div = num1 / num2;
    res.send('the value is '+div);
    }
})

app.listen(3000);