const express = require('express');
const app = express();
const bodyparser = require('body-parser');

app.use(bodyparser.urlencoded({extended:true}));

app.get('/',(req,res) => {
    res.sendFile(__dirname+'/index.html')
})

app.post('/',(req,res) => {
    const num1 = Number(req.body.n1);
    const num2 = Number(req.body.n2);
    const sub = num1 - num2;
    res.send('the value is '+sub);
})

app.listen(3000);