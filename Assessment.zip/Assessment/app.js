const bodyParser = require('body-parser');
const express = require('express');
const app = express();
const { Sequelize, DataTypes, STRING } = require('sequelize');

app.use(express.json());
app.use(bodyParser.urlencoded({extended:true}));

const model = new Sequelize({
    dialect: 'sqlite',
    storage: 'database.sqlite'
});

const userModel = model.define('user', {
    name: {
        type: DataTypes.STRING
    },
    email: {
        type: DataTypes.STRING
    },
    password: {
        type: DataTypes.STRING
    },
    mobile:{
        type: DataTypes.STRING
    }
  }, {
    freezeTableName: true
  });

userModel.sync();
// userModel.sync({ force: true });

app.get('/', (req, res) => {
    res.sendFile(__dirname+"/index.html")
})

app.get('/user/all', async (req, res) => {
    const showallusers = await userModel.findAll()
    res.json(showallusers)
})

app.post('/user/create', async (req, res) => {
    console.log(req.body)
    const newuser = await userModel.create(req.body)
    // res.send('sadfsa'+req.body)
    res.json({newuser})
    //  console.log(req.body)
})

app.get('/user/find_id/:id', async (req, res) => {
    const searchuserdata = await userModel.findByPk(req.params.id)
    res.json(searchuserdata)
})

app.get('/user/find_name/:id', async (req, res) => {
    const searchuserdata = await userModel.findOne({where:{name:req.params.id}})
    // const searchuserdata = await userModel.findOne({where:{name:"sjfsdb"}})
    res.json(searchuserdata)
})

app.post('/user/delete/:id', async(req, res) => {
    const deleteuser = await userModel.destroy(req.body, {where:{id:req.params.id}})
    res.send(deleteuser)
})

app.post('/user/update/:id', async(req, res) => {
    // const updateuser = await userModel.update(req.body, {where:{id:req.params.id}})
    const updateuser = await userModel.update({where:{id:req.params.id}}, req.body)
    res.send(updateuser)
})

app.post('/login',async(req,res,next)=>{
    const user = await userModel.findOne({ where : {email : req.body.email }});
    res.json(user);
        if(user){console.log('jfdsfsfsfssafass')}
        else {console.log('jfds')}
})

app.listen(3000);